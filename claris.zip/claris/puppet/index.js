const p=require('puppeteer');

const main=async()=>{
    const browser=await p.launch();
    let page =await browser.newPage()
    await page.on('response',(res)=>{
        let data=res.frame()
        let data=res.fromServiceWorker()
        let data=res.json()
        let data=res.ok()
        let data=res.remoteAddress()
        let data=res.status()
        let data=res.statusText()
        let data=res.text()
    })
}