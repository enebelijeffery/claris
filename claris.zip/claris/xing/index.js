const req=require('axios');
const fs=require('fs');
const main=async()=>{
    let options={
        method:'POST',
        headers:{
            'content-type': 'application/json; charset=utf-8',
            Host: 'login.xing.com',
            Origin: 'https://login.xing.com',
            'sec-ch-ua': '"Google Chrome";v="111", "Not(A:Brand";v="8", "Chromium";v="111"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': "Windows",
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36',
            'x-csrf-token' : 'cot-sWGN-O805uh2XQmxNWRJxowz37jS'
        },
        body:{
            "username":"tetstdy@gmsil.com"
        }
    }
    let result=await req('https://login.xing.com/login/api/recovery/password/reset_requests',options);
    console.log(result)
}
main()