const req=require('axios');
const fs=require('fs');
const main=async()=>{
    let options={
        method:'GET',
        header:{
            accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'content-length': '11738',
            'content-type': 'application/x-www-form-urlencoded',
            origin: 'https://www.linkedin.com',
            referer: 'https://www.linkedin.com/checkpoint/rp/request-password-reset',
            'sec-ch-ua': '"Google Chrome";v="111", "Not(A:Brand";v="8", "Chromium";v="111"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': "Windows",
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'
        }
    }
    let result=await req('https://www.linkedin.com/checkpoint/rp/request-password-reset',options);
    console.log(result)
    let data=await result.data;
    console.log(data.data)
    let options2={
        method:'POST',
        header:{
            accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'content-length': '11738',
            'content-type': 'application/x-www-form-urlencoded',
            origin: 'https://www.linkedin.com',
            referer: 'https://www.linkedin.com/checkpoint/rp/request-password-reset',
            'sec-ch-ua': '"Google Chrome";v="111", "Not(A:Brand";v="8", "Chromium";v="111"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': "Windows",
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'
        },
        body:{
            csrfToken: 'ajax:8182383915083592825',
            pageInstance: 'urn:li:page:checkpoint_rp_request_password_reset_default;BszXj3wYQmOTA9DusXywGQ==',
            userName: 'rtttiyu8fy@kk.op',
            encryptedEmail: false,
            fp_data: 'default'
        }
    }
    let result2=await req('https://www.linkedin.com/checkpoint/rp/request-password-reset-submit',options);
    let data2= await result2.data;
    let type = data.includes('associated');
    let valid=fs.createWriteStream('./index.html',{flags:'a'});
    // valid.write(data2);
    // console.log(type);
}
main()