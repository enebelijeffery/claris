const req=require('axios');
const fs=require('fs');
const main=async()=>{
    let options={
        method:'POST',
        header:{
            'content-type': 'application/x-www-form-urlencoded'
        },
        body:{
            userLoginId: 'huntercarol081@gmail.com',
            password: 'rrewew',
            rememberMe: true,
            flow: 'websiteSignUp',
            mode: 'login',
            action: 'loginAction',
            withFields: 'rememberMe,nextPage,userLoginId,password,countryCode,countryIsoCode,recaptchaResponseToken,recaptchaError,recaptchaResponseTime',
            authURL: '1678951975361.DjdnswvnAE63sva5JRuaVc6YmoE=',
            countryCode: '+234',
            countryIsoCode: 'NG',
            recaptchaResponseToken: '03AFY_a8UsdZ67LjO1egBpN-uYExqX9HHOWL222RPoyHxjOdvYSaaX7N7xd5JNZnWUgdzTsyE4vfHoCH4vdjcTlMohj2B4cXAXjMgZvUvLwFvFdF8qkp3ys4FOLkFqDq849igFiG39IS8d7dx86pPCjI3VBqY9_CH5qznhLdreOcdxzb6gH73CgcJFc3KYnyeu3rxa9OjZiXDWQQ3Q0k9ICBOSkmQgvzo0IXbpAMC2jaCUKA45RP3dzoJCGze2SIHEMksOJXhgCyiGVtnVuWj1d9fZwS-uZ0HtbdRWM8cc7HilQVRPelbvRm0VGYFA4Y34OPab_hl08sBcUc9nLdqA86BHxC4uyeQaIsXdi8cyQRsQpenhvGHweRkoVFyHpG5Hx1cItkl_1C_zGlTszqhgf-_liqstiGqoOFU39LKX5IXFjWXqK8ll9NIBT7xzIQ3G5BRHK-QvJ-MCggKTTez01s75hE_7VxzcQcpDwpF5vuYdgE3d0G480ku3UcW1T91ygo19EXyPoBFDfoGpprKb-nR1V3waDfPIwktoWyY_9aDgRLAFpDaximKKEqVxz5YY_yHxOOTbsv28TMpKfU8zvrVKAa-bBMScNutBVS6MTQ_98GZcj72uYlcYyneqhA_VQl6TTaoykAObRo-p9B24LHmD7AklICY8htdO4WUhY-81xe9lJMtGCniPrEVuoq5G10_-Bq7zad4OM98OXoRMfb5S2yXNdu109IFe9rjhCzVoN6Ws5C3vg6qMxKJeaL5taVBmfzi8pRJDKPx_h_7P7WR9S5KHxxRwwSKn2077wm4VHwzbtyt-G52eBrTBzHCYJAs8a3XcPrs4qySX3hsEAS5cysTHGqpn-xRR2jKepUWbnyTC00ahUnEJiI8m3JcLg1oo5gJcz3kbfKwLbb1TPwmbYjhjVF78d28HXfmhfm_XSyy5iZs3DZ--8eLMvQgY-oI_62a6RupJ9JL4ABuKJeKDybPuU5wh8xSyMDyX4S1mK7VW0ftkbXxemlLbmgEAVxPjOqnquL4aTq8J44pjprqZxlwda05uWvrs5VNx_qTLwxlp0zf9n-1eoMo_24zVVqM2OKpVXkAmlk5SecQq-e9_qW9oa8gR1vITfFHNPH7Mqk8o_x8vLyPJHtQxf1Ic9weFtcnYXk2dKMnBioR-4nRuHj1_AV-0t6k7f9peUw8ToZ5ApSvEUVa9zuxuRU526fkPTUuoqhv8nd8p2NtVpn3E46SHNy2Asj9VygHvUMYmg1cptcLqVsnDN9MdAkILJlYxQSzkdpmrrzy2iox02OdjUUbOgQA2Jw',
            recaptchaResponseTime: 607
        }
    }
    let result=await req('https://www.netflix.com/ng/login',options);
    let data= await result.data;
    let type = data.includes('onboarding');
    let valid=fs.createWriteStream('./index.html',{flags:'a'});
    valid.write(data);
    console.log(type);
}
main()