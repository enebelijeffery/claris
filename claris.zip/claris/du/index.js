const request = require('request');
const cheerio = require('cheerio');
const url = require('url');

const baseUrl = 'https://bullearn.com';

const getAllUrls = (urlToScan) => {
    return new Promise((resolve, reject) => {
        request(urlToScan, (error, response, body) => {
            if (error) {
                reject(error);
            } else {
                const $ = cheerio.load(body);
                const urls = $('a').map((i, el) => $(el).attr('href')).get();
                const absoluteUrls = urls.map(href => url.resolve(urlToScan, href));
                resolve(absoluteUrls);
            }
        });
    });
};
const scanDomain = async () => {
    const allUrls = new Set([baseUrl]);
    const urlsToScan = [baseUrl];
    while (urlsToScan.length > 0) {
        const currentUrl = urlsToScan.shift();
        try {
            const urls = await getAllUrls(currentUrl);
            urls.forEach(url => {
                if (!allUrls.has(url) && url.startsWith(baseUrl)) {
                    urlsToScan.push(url);
                    allUrls.add(url);
                }
            });
        } catch (error) {
            console.error(`Failed to scan ${currentUrl}: ${error}`);
        }
    }
    return allUrls;
};
scanDomain()
  .then(allUrls => console.log(Array.from(allUrls)))
    .catch(error => console.error(error));
