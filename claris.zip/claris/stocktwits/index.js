const fs= require('fs');
const readline=require('readline');
const axios=require('axios');

const main=async()=>{

    
    
    const getEmail=async()=>{
        let emailList= [];

        let readStream =  fs.createReadStream('./emails.txt');
         const rl= readline.createInterface({
            input: readStream,
            crlfDelay: Infinity           
         });
        for await (const line of rl){
            emailList.push(encodeURIComponent(line));
        }
       return emailList;
    }
    let emailList= await getEmail();
    let proxyList=[ 
        '159.203.31.27:8118',
        '54.226.96.19:80',
        '3.220.76.84:80',
        '3.84.184.94:9999',
        '104.248.12.97:80',
        '129.213.138.44:3128',
        '51.222.12.245:10084',
        '172.245.187.99:80',
        '45.42.177.58:3128',
        '67.207.89.36:59166',
        '142.44.241.192:59166',
        '159.89.91.243:59166',
    ]
    // let proxy=proxyList.map(async(p)=>{
    //     let result = await axios.default(`https;://${p}`)
    //     console.log(result)
    //  })
    let validate=async(i)=>{

        let url = `https://stocktwits.com/api/auth/emailAvailable?email=${i}&get_unverified_user_id=false`;
        let result=await axios(url,{method:'get'});
        let data= await result.data
        console.log(data)
        return data
    }
    let count=1
    let loop=emailList.map(async(i)=>{
        let result=await validate(i);
        if (result.available===false) {
            let write=fs.createWriteStream('./validmail.txt',{flags:'a'});
            write.write(`${i}\n`)
        }
        ++count
        console.log(count)
        })
    
    console.log(count);
}
main()
