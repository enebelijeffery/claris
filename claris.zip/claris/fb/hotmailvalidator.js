const puppeteer = require('puppeteer-extra');
const stealthPlugin = require('puppeteer-extra-plugin-stealth');
const {executablePath, TimeoutError, HTTPResponse, }=require('puppeteer');
const proxy=require('puppeteer-page-proxy');
const readline=require('readline');
const fs=require('fs')

puppeteer.use(stealthPlugin());

const url='https://www.amazon.com/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3F_encoding%3DUTF8%26ref_%3Dnav_em_hd_re_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&&ref_%3Dnav_em_hd_clc_signin'


const main =async()=>{
    console.log('> starting program')
    const main =async(email)=>{
        let browser= await puppeteer.launch({
            headless:true,
            executablePath:executablePath(),
            // args:['--proxy-server=157.90.159.179:8080']
        })
        let ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'
        let page= await browser.newPage();
        await page.setUserAgent(ua)
        await page.goto(url,{waitUntil:'networkidle2'});
        await page.type('#ap_email',email);
        await page.click('#continue')
        await page.waitForNavigation({timeout:10000})
        let selector=async () =>{
            let idselector =await page.$('#ap_change_login_claim')
            console.log('id',idselector)
            if (idselector !==null) {
                return true
            } else{
                return false
            }
        }    
        let select= await selector()
        console.log(email,select)
        await browser.close()
        return select
    }
    
    const getEmail=async()=>{
        let emailList=[]
        let readStream =  fs.createReadStream('./email.txt');
         const rl= readline.createInterface({
            input: readStream,
            crlfDelay: Infinity           
         });
        for await (const line of rl){
            emailList.push(line);
        }
       return emailList;
    }
    let emailList=await getEmail();
    const loop =async ()=>{
        for (const email of emailList) {
            console.log(email);
            let result= await main(email)
            if (await result===true) {
                let write=fs.createWriteStream('./hit.txt',{flags:'a'});
                write.write(`${email}\n`);
            }
        }
    }
    loop()
}
main()
