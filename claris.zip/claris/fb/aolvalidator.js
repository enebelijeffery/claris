const puppeteer = require('puppeteer-extra');
const stealthPlugin = require('puppeteer-extra-plugin-stealth');
const {executablePath, TimeoutError, HTTPResponse, }=require('puppeteer');
const proxy=require('puppeteer-page-proxy');
const readline=require('readline');
const fs=require('fs');
const { throws } = require('assert');

puppeteer.use(stealthPlugin());

const url='https://oidc.www.aol.com/login/?lang=en-us&intl=us&src=fp-us&dest=https%3A%2F%2Fwww.aol.com%2F'


const main =async()=>{
    console.log('> starting program')
    const main =async(email)=>{
        let browser= await puppeteer.launch({
            headless:true,
            executablePath:executablePath(),
            // args:['--proxy-server=157.90.159.179:8080']
        })
        let ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'
        let page= await browser.newPage();
        await page.setUserAgent(ua)
        await page.goto(url,{waitUntil:'networkidle2'});
        await page.type('#login-username',email);
        await page.click('#login-signin')
        
       try {
        await page.waitForNavigation({timeout:10000})
        let selector=async () =>{
            let idselector =await page.$('#login-passwd')
            console.log('id',idselector)
            if (idselector !==null) {
                return true
            } else{
                return true
            }
        }    
        let select= await selector()
        console.log(email,select)
        await browser.close()
        return select
       } catch (error) {
        let selector=async () =>{
            let idselector =await page.$('#username-error')
            console.log('id',idselector)
            if (idselector !==null) {
                return false
            }
        }    
        let select= await selector()
        console.log(email,select)
       }
    }
    
    const getEmail=async()=>{
        let emailList=[]
        let readStream =  fs.createReadStream('./aol.txt');
         const rl= readline.createInterface({
            input: readStream,
            crlfDelay: Infinity           
         });
        for await (const line of rl){
            emailList.push(line);
        }
       return emailList;
    }
    let emailList=await getEmail();
    const loop =async ()=>{
        for (const email of emailList) {
            console.log(email);
            let result= await main(email)
            if (await result===true) {
                let write=fs.createWriteStream('./aolhit.txt',{flags:'a'});
                write.write(`${email}\n`);
            }
        }
    }
    loop()
}
main()
