const fs=require('fs');
const readline=require('readline');

const emailFilter=async()=>{
    const getEmail=async()=>{
        let mailList=[]
        let mails=fs.createReadStream('./email.txt');
        let rl=readline.createInterface({input:mails});
        for await (const line of rl) {
            mailList.push(line)  
        }
        return mailList;
    }
    const filter=async()=>{
        let mailList = await getEmail()
        for(const line of mailList){
            let splitmail=line.split(':');
            let mail=splitmail[0]
            if (mail.includes('gmail.com')) {
                let write=fs.createWriteStream('./gmail.txt',{flags:'a'});
                write.write(`${mail}\n`);
            } else if(mail.includes('yahoo.com')){
                let write=fs.createWriteStream('./yahoo.txt',{flags:'a'});
                write.write(`${mail}\n`);
            }else if (mail.includes('hotmail.com')) {
                let write=fs.createWriteStream('./hotmail.txt',{flags:'a'});
                write.write(`${mail}\n`);
            } else if(mail.includes('outlook.com')){
                let write=fs.createWriteStream('./outlook.txt',{flags:'a'});
                write.write(`${mail}\n`);
            }else if (mail.includes('aol.com')) {
                let write=fs.createWriteStream('./aol.txt',{flags:'a'});
                write.write(`${mail}\n`);
            } else {
                let write=fs.createWriteStream('./others.txt',{flags:'a'});
                write.write(`${mail}\n`);
            }
        }
    }
    filter()
}
emailFilter()