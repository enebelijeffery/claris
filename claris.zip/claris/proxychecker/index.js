const fs = require('fs');
const proxyCheck = require('proxycheck-node.js')

// Define the list of proxy servers to check
let proxyList=[ 
  '159.203.31.27:8118',
  '54.226.96.19:80',
  '3.220.76.84:80',
  '3.84.184.94:9999',
  '104.248.12.97:80',
  '129.213.138.44:3128',
  '51.222.12.245:10084',
  '172.245.187.99:80',
  '45.42.177.58:3128',
  '67.207.89.36:59166',
  '142.44.241.192:59166',
  '159.89.91.243:59166',
]




const main=async()=>{
  const testUrl = 'https://example.com';
  const blacklistEndpoint = 'https://api.proxycheck.io/v2/159.89.91.243:59166?key=66395r-7cry03-974304-99c8b4';
  const apiKey = '6118x7-c73e19-463586-9177o5';
  

  const checker=async(ip)=>{
    const check= new proxyCheck({api_Key:apiKey})
    let result= await check.check(ip);
    console.log(result)
    return result;
  }
  let liveProxy=proxyList.map(async(i)=>{
    let ip=i.split(':');
    let result= await checker(ip[0]);
    // console.log( result)
    let status = await result.status
    // let proxyType= await result.ip[0].type
    console.log( status)
    
    if (status==='ok') {
      let write= fs.createWriteStream('./live.txt',{flags:'a'});
      write.write(i)
    }
  })

}
main()