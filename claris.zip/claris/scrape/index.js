const axios = require('axios');
const cheerio = require('cheerio');

axios.get('https://www.reddit.com/').then(response => {
  const $ = cheerio.load(response.data);
  const titles = [];
  const urls = [];

  $('a[data-click-id="body"]').each((i, elem) => {
    if (i < 10) {
      titles.push($(elem).text());
      urls.push($(elem).attr('href'));
    }
  });

  console.log('Titles:', titles);
  console.log('URLs:', urls);
}).catch(error => {
  console.log(error);
});
