const fs= require('fs');
const readline=require('readline');

const axios=require('axios');

let options={

    headers:{
        'content-type':'application/x-www-form-urlencode'
    } ,
    body:{
        password:'',
        email:'efarfa@gmail.com',
        appAction:'SIGNIN_PWD_COLLECT',
        subPageType: 'SignInClaimCollect',
    }

}
axios.post('https://www.amazon.com/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_custrec_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&',options).then((prom)=>{
    console.log(prom)
   let f=fs.createWriteStream('./i.txt',{flags:'a'});
   f.write(res.data);
})
