const axios =require('axios');

let url=' https://www.instagram.com/api/v1/web/accounts/account_recovery_send_ajax/';

const validate=async()=>{
    let result=await axios(url,{
        method:'post',
        header:{
            'content-type': 'application/x-www-form-urlencoded',
        },
        data:{
            email_or_username:"esdrauayy%40yay.com",
            recaptcha_challenge_field: ''
        }
    })
    console.log(result)
    return result
}

validate()
